from setuptools import find_packages
from setuptools import setup

REQUIRED_PACKAGES = [
	'pandas',
	'progressbar2',
	'python-utils',
	'tensorflow',
	'numpy',
	'scipy',
	'paramiko',
	'pysftp',
	'sox',
	'python_speech_features',
	'pyxdg',
	'bs4',
	'six',
	'pypi-kenlm==0.1.20160618',
]

setup(
    name='trainer',
    version='0.1',
    install_requires=REQUIRED_PACKAGES,
    packages=find_packages(),
    include_package_data=True,
    description='My trainer application package.'
)
